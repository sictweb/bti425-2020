import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

import { AppComponent } from './app.component';
import { NavComponent } from './nav.component';
import { HomeComponent } from './home.component';
import { TeamListComponent } from './team-list.component';
import { TeamDetailComponent } from './team-detail.component';
import { TeamCreateComponent } from './team-create.component';
import { TeamEditComponent } from './team-edit.component';
import { NotFoundComponent } from './not-found.component';
import { DataManagerService } from './data-manager.service';


@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    TeamListComponent,
    TeamDetailComponent,
    TeamCreateComponent,
    TeamEditComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [DataManagerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
