import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav.component';
import { NotFoundComponent } from './not-found.component';
import { HomeComponent } from './home.component';
import { AboutComponent } from './about.component';
import { ContactComponent } from './contact.component';
import { TypicodeComponent } from './typicode.component';
import { FormExampleComponent } from './form-example.component';

// These were added to enable a clean and successful "ng build --prod"
import { UserListComponent } from './user-list.component';
import { UserDetailComponent } from './user-detail.component';
import { UserCreateComponent } from './user-create.component';
import { UserEditComponent } from './user-edit.component';
import { UserDeleteComponent } from './user-delete.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    NotFoundComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    TypicodeComponent,
    FormExampleComponent,
    UserListComponent,
    UserDetailComponent,
    UserCreateComponent,
    UserEditComponent,
    UserDeleteComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
