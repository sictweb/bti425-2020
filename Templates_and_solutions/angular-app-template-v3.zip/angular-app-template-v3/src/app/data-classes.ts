
// Data model classes for the app

// Example - describes a product
export class Product {
  id: number;
  name: string;
  description?: string;   // optional property, can be null
}

// Add more data model classes below...



// From the "typicode" web API...
// https://jsonplaceholder.typicode.com

export class Post {
  id:         number;
  userId:     number;
  title:      string;
  body:       string;
}

export class Comment {
  id:         number;
  postId:     number;
  email:      string;
  name:       string;
  body:       string;
}

export class Geo {
  lat:        number;
  lng:        number;
}

export class Address {
  city:       string;
  geo:        Geo;
  street:     string;
  suite:      string;
  zipcode:    string;
}

export class Company {
  bs:             string;
  catchPhrase:    string;
  name:           string;
}

export class User {
  address:        Address;
  company:        Company;
  email:          string;
  id:             number;
  name:           string;
  phone:          string;
  username:       string;
  website:        string;
}



// From the "request response" web API...
// https://reqres.in

// User 
export class ReqresUser {
  id: number;
  first_name: string;
  last_name: string;
  avatar: string;
}

// Package that delivers a collection of users
export class ReqresUserCollectionPackage {
  page?: number;
  per_page?: number;
  total?: number;
  total_pages?: number;
  data: ReqresUser[];
}

// Package that delivers one user
export class ReqresUserSinglePackage {
  page?: number;
  per_page?: number;
  total?: number;
  total_pages?: number;
  data: ReqresUser;
}

// Packaging for "add new" request
// NOTICE...
// The same package works for the "edit existing" request
export class ReqresUserCreate {
  name: string;
  job: string;
}

// Response from "add new" POST request
// NOTICE...
// The same package works for the "edit existing" request, 
// except that the web service does NOT return the "id" value,
// which is why it has been configured (below) as optional
export class ReqresUserCreateResponse {
  id?: number;
  name: string;
  job: string;
  createdAt: string;  // ISO8601 date and time string
}
