import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { catchError, tap } from "rxjs/operators";

// Import data model classes, for example...
//import { Product } from "./data-classes";
import { Post, Comment, Geo, Address, Company, User } from "./data-classes";
import { ReqresUser, ReqresUserCollectionPackage, ReqresUserSinglePackage, ReqresUserCreate, ReqresUserCreateResponse } from "./data-classes";

@Injectable({
  providedIn: 'root'
})
export class DataManagerService {

  // Inject the HttpClient
  constructor(private http: HttpClient) { }

  // Base URL for the example typicode web API
  //private url: string = 'https://example.com/api';
  private url: string = 'https://jsonplaceholder.typicode.com';

  // Base URL to the example reqres.in web API
  private urlReqres: string = "https://reqres.in/api/users";

  // Options object for POST and PUT requests
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  // Error handler, from the Angular docs
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }



  // ############################################################
  // Data service operations - typicode web API

  // Callable methods...
  // For each entity, as appropriate, get, add, edit, delete
  // Add other methods that provide general service to all components in the app

  getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.url}/posts`)
  }

  getComments(): Observable<Comment[]> {
    return this.http.get<Comment[]>(`${this.url}/comments`)
  }

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.url}/users`)
  }



  // ############################################################
  // Data service operations - reqres.in web API

  // Get all
  reqresUserGetAll(): Observable<ReqresUserCollectionPackage> {
    return this.http.get<ReqresUserCollectionPackage>(`${this.urlReqres}?per_page=8`);
  }

  // Get one
  reqresUserGetById(id: number): Observable<ReqresUserSinglePackage> {
    return this.http.get<ReqresUserSinglePackage>(`${this.urlReqres}/${id}`);
  }

  // Add new
  reqresUserAdd(newItem: ReqresUserCreate): Observable<ReqresUserCreateResponse> {
    return this.http.post<ReqresUserCreateResponse>(this.urlReqres, newItem, this.httpOptions)
      .pipe(
        tap((newItem: ReqresUserCreateResponse) => console.log(`Added item ${newItem.name}`)),
        catchError(this.handleError<ReqresUserCreateResponse>('User add'))
      );
  }

  // Edit existing
  reqresUserEdit(id: number, newItem: ReqresUserCreate): Observable<ReqresUserCreateResponse> {
    return this.http.put<ReqresUserCreateResponse>(`${this.urlReqres}/${id}`, newItem, this.httpOptions)
      .pipe(
        tap((newItem: ReqresUserCreateResponse) => console.log(`Edited item ${newItem.name}`)),
        catchError(this.handleError<ReqresUserCreateResponse>('User edit'))
      );
  }

  // Delete item
  reqresUserDelete(id: number) {
    return this.http.delete(`${this.urlReqres}/${id}`)
      .pipe(
        tap(() => console.log(`Deleted item with id ${id}`)),
        catchError(this.handleError('User delete'))
      );
  }

}
